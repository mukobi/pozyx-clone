## import the serial library
import serial

fileName= input('Enter file name: ') #ask user to name the file
fileType= '.csv' #set file type

def OpenScaleData():
    ser=serial.Serial('COM8',115200)
    ser2=serial.Serial('COM11', 115200)

    text_file = open(fileName+fileType, 'w')
    text_file.write(' ,time,force,units, ,x ,y ,z, ,acceleration[0], acceleration[1], acceleration[2], heading, roll, pitch, lin_acceleration 0, lin_acceleration 1, lin_acceleration 2, \n')
## read serial data from arduino 
    while 1:
        if ser.inWaiting():

            x=ser.readline()
            print(x)
            text_file.write(str (x))
           
            x1=ser2.readline() 
            print(x1)
            text_file.write(str(x1))
            text_file.write('\n')

            if x1=='\n':
                text_file.seek(0)
                text_file.truncate()
            text_file.flush()

## close the serial connection and text file
    text_file.close()
    ser.close()
    ser2.close()
OpenScaleData()
